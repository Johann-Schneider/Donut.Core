package de.donut4gamer.donutcore.listeners;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class TabList implements Listener {
    private final JavaPlugin plugin;
    private final FileConfiguration config;
    private final int updateInterval;

    public TabList(JavaPlugin plugin) {
        this.plugin = plugin;
        this.config = plugin.getConfig();
        this.updateInterval = config.getInt("tablist.update-interval", 100); // Default: 100 Ticks (5 Sekunden)
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // Automatisches Update der Tablist in regelmäßigen Abständen
        new BukkitRunnable() {
            @Override
            public void run() {
                // Wenn Tablist deaktiviert ist, den Task abbrechen
                if (!config.getBoolean("tablist.enabled", true)) {
                    cancel();
                    return;
                }

                // Header und Footer aus der Config holen
                String header = getFormattedLines(config.getStringList("tablist.header"), player);
                String footer = getFormattedLines(config.getStringList("tablist.footer"), player);

                // Farbcodes und Platzhalter ersetzen
                header = ChatColor.translateAlternateColorCodes('&', header);
                footer = ChatColor.translateAlternateColorCodes('&', footer);

                // Den Tablist-Header und -Footer setzen
                player.setPlayerListHeader(header);
                player.setPlayerListFooter(footer);
            }
        }.runTaskTimer(plugin, 0L, updateInterval);  // Task läuft alle `updateInterval` Ticks
    }

    // Hilfsmethode, um die Zeilen mit Platzhaltern zu ersetzen
    private String getFormattedLines(java.util.List<String> lines, Player player) {
        StringBuilder formatted = new StringBuilder();
        for (String line : lines) {
            line = PlaceholderAPI.setPlaceholders(player, line); // Platzhalter ersetzen
            line = ChatColor.translateAlternateColorCodes('&', line); // Farbcodes ersetzen
            formatted.append(line).append("\n"); // Zeilen hinzufügen
        }
        return formatted.toString().trim(); // Entfernt unnötige Zeilenumbrüche am Ende
    }
}
